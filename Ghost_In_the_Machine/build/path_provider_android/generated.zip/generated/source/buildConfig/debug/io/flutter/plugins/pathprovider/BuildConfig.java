/**
 * Automatically generated file. DO NOT MODIFY
 */
package io.flutter.plugins.pathprovider;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String LIBRARY_PACKAGE_NAME = "io.flutter.plugins.pathprovider";
  public static final String BUILD_TYPE = "debug";
}
