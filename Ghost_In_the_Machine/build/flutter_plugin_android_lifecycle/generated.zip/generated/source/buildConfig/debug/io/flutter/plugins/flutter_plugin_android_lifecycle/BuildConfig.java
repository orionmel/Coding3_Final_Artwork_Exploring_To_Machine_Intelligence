/**
 * Automatically generated file. DO NOT MODIFY
 */
package io.flutter.plugins.flutter_plugin_android_lifecycle;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String LIBRARY_PACKAGE_NAME = "io.flutter.plugins.flutter_plugin_android_lifecycle";
  public static final String BUILD_TYPE = "debug";
}
